﻿using System;

namespace GorillaShirts.Models
{
    [Serializable]
    public class SDescriptor
    {
        public string shirtName;
        public string shirtAuthor;
        public string shirtDescription;
    }
}
