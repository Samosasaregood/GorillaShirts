﻿using GorillaShirts.Models;
using UnityEngine;

namespace GorillaShirts.Behaviours.Visuals
{
    public class VisualParent : MonoBehaviour
    {
        public Rig Rig;
    }
}
