﻿namespace GorillaShirts.Interaction
{
    public enum ButtonType
    {
        ShirtEquip, ShirtLeft, ShirtRight, PackLeft, PackRight,
        RigToggle, Randomize, TagIncrease, TagDecrease, AdvancedTab, Capture
    }
}
